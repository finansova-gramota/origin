<div id="UM_fonticons" style="display:none">

	<div class="um-admin-modal-head">
		<h3><?php printf(__('Choose from %s available icons','ultimate-member'), count( $ultimatemember->icons->all ) ); ?></h3>
	</div>

	<div class="um-admin-modal-body">
		
	</div>
	
	<div class="um-admin-modal-foot">
		<a href="#" class="button-primary um-admin-modal-back" data-code="">Finish</a>
		<a href="#" class="button um-admin-modal-back um-admin-modal-cancel">Cancel</a>
	</div>
	
</div>