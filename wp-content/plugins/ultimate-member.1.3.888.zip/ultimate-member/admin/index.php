<?php

// Silence is golden.

?>